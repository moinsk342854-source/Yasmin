package com.yesmin.ai.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class YesminAccessibilityService : AccessibilityService() {
    companion object {
        var instance: YesminAccessibilityService? = null
        private val BLOCKED = Regex("pay|send|delete|submit|buy|purchase|transfer|order|confirm|bhejo|kharido", RegexOption.IGNORE_CASE)
    }
    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun note(s: String) = Toast.makeText(this, "Yesmin: $s", Toast.LENGTH_SHORT).show()

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }

    fun tap(x: Float, y: Float): String { note("tap"); swipe(x, y, x, y); return "Tap kar diya" }

    fun scroll(down: Boolean): String {
        val d = resources.displayMetrics; val w = d.widthPixels / 2f; val h = d.heightPixels.toFloat()
        note(if (down) "scroll down" else "scroll up")
        if (down) swipe(w, h * .7f, w, h * .3f) else swipe(w, h * .3f, w, h * .7f)
        return "Scroll ho gaya"
    }

    fun back(): String { note("back"); performGlobalAction(GLOBAL_ACTION_BACK); return "Back" }
    fun home(): String { note("home"); performGlobalAction(GLOBAL_ACTION_HOME); return "Home" }

    fun clickText(text: String): String {
        if (BLOCKED.containsMatchIn(text)) return "Safety: '$text' jaise sensitive button main khud nahi dabaungi. Aap manually dabayein."
        val root = rootInActiveWindow ?: return "Screen padh nahi paayi"
        var n: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return "'$text' screen par nahi mila"
        while (n != null && !n.isClickable) n = n.parent
        if (n == null) return "'$text' clickable nahi hai"
        note("click '$text'"); n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return "'$text' dabaya"
    }
}
