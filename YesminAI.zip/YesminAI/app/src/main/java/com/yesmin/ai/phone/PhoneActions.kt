package com.yesmin.ai.phone

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONObject

class PhoneActions(private val ctx: Context) {
    companion object { val A11Y = setOf("tap", "scroll", "click_text", "back", "home") }

    private fun start(i: Intent): String { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Ho gaya ✅" }

    fun run(j: JSONObject): String = try {
        when (j.optString("type")) {
            "open_app" -> openApp(j.getString("name"))
            "open_youtube" -> openApp("YouTube")
            "youtube_search" -> yt(j.getString("query"))
            "settings" -> start(Intent(Settings.ACTION_SETTINGS))
            "camera" -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "browser" -> start(Intent(Intent.ACTION_VIEW, Uri.parse(j.optString("url", "https://www.google.com"))))
            "alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, j.getInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, j.optInt("minute", 0))
                .putExtra(AlarmClock.EXTRA_MESSAGE, j.optString("label", "Yesmin reminder")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "flashlight" -> torch(j.optBoolean("on", true))
            "volume" -> volume(j.optString("dir"))
            in A11Y -> a11y(j)
            else -> "Ye action mujhe nahi aata"
        }
    } catch (e: Exception) { "Fail hua: ${e.message}" }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val m = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return "'$name' app nahi mila"
        return start(pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!)
    }

    // Opens YouTube search results (auto-play of a specific video needs the YouTube Data API).
    private fun yt(q: String): String = try {
        start(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q))
    } catch (e: Exception) {
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); return if (on) "Torch ON 🔦" else "Torch OFF"
    }

    private fun volume(dir: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_TOGGLE_MUTE }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI); return "Volume $dir"
    }

    private fun a11y(j: JSONObject): String {
        val s = YesminAccessibilityService.instance ?: return "Pehle Accessibility service enable karo (Tools tab)"
        return when (j.getString("type")) {
            "tap" -> s.tap(j.getDouble("x").toFloat(), j.getDouble("y").toFloat())
            "scroll" -> s.scroll(j.optString("dir") == "down")
            "click_text" -> s.clickText(j.getString("text"))
            "back" -> s.back()
            else -> s.home()
        }
    }
}
