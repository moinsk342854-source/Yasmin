package com.yesmin.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yesmin.ai.ui.App
import com.yesmin.ai.ui.Cyan
import com.yesmin.ai.ui.MainViewModel
import com.yesmin.ai.ui.Purple
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(darkColorScheme(primary = Cyan, secondary = Purple, background = Color.Black, surface = Color(0xFF0B0B12))) {
                App(viewModel<MainViewModel>())
            }
        }
    }
}
