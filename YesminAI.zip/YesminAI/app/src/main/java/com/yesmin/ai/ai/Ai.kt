package com.yesmin.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val text: String) // role: "user" | "assistant"

object Ai {
    val providers = listOf("gemini" to "Google Gemini (Primary)", "claude" to "Claude (Optional)")
    fun defaultModel(id: String) = if (id == "gemini") "gemini-2.5-flash" else "claude-sonnet-4-5"

    suspend fun chat(id: String, key: String, model: String, system: String, h: List<Msg>): String =
        withContext(Dispatchers.IO) { if (id == "gemini") gemini(key, model, system, h) else claude(key, model, system, h) }

    private fun gemini(key: String, model: String, system: String, h: List<Msg>): String {
        val contents = JSONArray()
        h.forEach { contents.put(JSONObject().put("role", if (it.role == "user") "user" else "model")
            .put("parts", JSONArray().put(JSONObject().put("text", it.text)))) }
        val body = JSONObject().put("contents", contents).put("system_instruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val r = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to key), body.toString())
        return JSONObject(r).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun claude(key: String, model: String, system: String, h: List<Msg>): String {
        val msgs = JSONArray()
        h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model).put("max_tokens", 1500).put("system", system).put("messages", msgs)
        val r = post("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
        return JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw Exception("HTTP $code: ${s.take(200)}")
        return s
    }
}
