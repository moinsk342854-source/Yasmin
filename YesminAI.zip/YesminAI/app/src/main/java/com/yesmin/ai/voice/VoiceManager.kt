package com.yesmin.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceManager(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val fail: (String) -> Unit
) {
    private var tts: TextToSpeech? = TextToSpeech(ctx) { }
    private var sr: SpeechRecognizer? = null

    fun speak(text: String, tag: String) {
        val t = tts ?: return
        val loc = Locale.forLanguageTag(tag)
        t.language = loc
        t.voices?.filter { it.locale.language == loc.language }?.let { vs ->
            (vs.firstOrNull { it.name.contains("female", true) } ?: vs.firstOrNull())?.let { t.voice = it }
        }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin")
    }

    /** Interrupt: stops speech immediately. Called whenever the mic is pressed. */
    fun stopSpeaking() { tts?.stop() }

    fun stopListening() { sr?.stopListening(); onListening(false) }

    fun listen(tag: String) {
        stopSpeaking(); sr?.destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { fail("Is phone par speech recognition available nahi hai"); return }
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { onListening(true) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { onListening(false); fail("Mic error code $e") }
                override fun onResults(b: Bundle?) {
                    onListening(false)
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
                }
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag))
        }
    }

    fun shutdown() { sr?.destroy(); tts?.shutdown() }
}
