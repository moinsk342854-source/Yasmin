package com.yesmin.ai.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray

/** All settings, API keys and memory live in AES-256 encrypted prefs. */
class Store(ctx: Context) {
    private val p = EncryptedSharedPreferences.create(
        ctx, "yesmin_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun key(id: String) = p.getString("key_$id", "") ?: ""
    fun model(id: String) = p.getString("model_$id", null) ?: com.yesmin.ai.ai.Ai.defaultModel(id)
    fun enabled(id: String) = p.getBoolean("on_$id", false)
    fun save(id: String, key: String, model: String, on: Boolean) =
        p.edit().putString("key_$id", key.trim()).putString("model_$id", model.trim()).putBoolean("on_$id", on).apply()
    var lang: String
        get() = p.getString("lang", "hi-IN") ?: "hi-IN"
        set(v) = p.edit().putString("lang", v).apply()
    var memory: List<String>
        get() = JSONArray(p.getString("memory", "[]")).let { a -> List(a.length()) { a.getString(it) } }
        set(v) = p.edit().putString("memory", JSONArray(v).toString()).apply()
}
