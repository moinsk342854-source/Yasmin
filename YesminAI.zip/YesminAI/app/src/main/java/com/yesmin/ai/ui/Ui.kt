package com.yesmin.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.yesmin.ai.ai.Ai
import com.yesmin.ai.phone.YesminAccessibilityService

val Cyan = Color(0xFF00E5FF)
val Purple = Color(0xFF9B5CFF)

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val s = RoundedCornerShape(20.dp)
    Column(modifier.clip(s).background(Color.White.copy(0.06f)).border(1.dp, Cyan.copy(0.25f), s).padding(14.dp), content = content)
}

@Composable
fun App(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🏠" to "Home", "💬" to "Chat", "🧰" to "Tools", "🧠" to "Memory", "⚙️" to "Settings")
    Scaffold(containerColor = Color.Black, bottomBar = {
        NavigationBar(containerColor = Color(0xFF0B0B12)) {
            tabs.forEachIndexed { i, t -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(t.first) }, label = { Text(t.second, fontSize = 10.sp) }) }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> Home(vm); 1 -> Chat(vm); 2 -> Tools(vm) { tab = 1 }; 3 -> MemoryScreen(vm); else -> SettingsScreen(vm) }
        }
        vm.pendingAction?.let { a ->
            AlertDialog(onDismissRequest = { vm.pendingAction = null }, title = { Text("Screen action confirm karo") },
                text = { Text("Yesmin ye karna chahti hai:\n$a") },
                confirmButton = { TextButton({ vm.confirmAction() }) { Text("Allow") } },
                dismissButton = { TextButton({ vm.pendingAction = null }) { Text("Cancel") } })
        }
        vm.pendingMemory?.let { m ->
            AlertDialog(onDismissRequest = { vm.pendingMemory = null }, title = { Text("Yaad rakhun?") }, text = { Text(m) },
                confirmButton = { TextButton({ vm.approveMemory() }) { Text("Save") } },
                dismissButton = { TextButton({ vm.pendingMemory = null }) { Text("Nahi") } })
        }
    }
}

@Composable
fun Core(active: Boolean) {
    val t = rememberInfiniteTransition(label = "core")
    val s by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(if (active) 600 else 2200), RepeatMode.Reverse), label = "s")
    Canvas(Modifier.size(220.dp)) {
        val r = size.minDimension / 2 * s * 0.8f
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(.5f), Purple.copy(.2f), Color.Transparent)), radius = r * 1.3f)
        drawCircle(Cyan, r * 0.7f, style = Stroke(3.dp.toPx()))
        drawCircle(Purple, r * 0.5f, style = Stroke(2.dp.toPx()))
        drawCircle(Brush.radialGradient(listOf(Color.White, Cyan)), r * 0.25f)
    }
}

@Composable
fun MicButton(vm: MainViewModel) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) vm.toggleMic() }
    Button(onClick = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleMic()
        else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }) { Text(if (vm.listening) "⏹ Sun rahi hoon…" else "🎤 Bolo") }
}

@Composable
fun InputRow(vm: MainViewModel) {
    var t by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Kuch poochho…") }, singleLine = true)
        Spacer(Modifier.width(8.dp))
        Button({ vm.send(t); t = "" }, enabled = !vm.busy) { Text("➤") }
    }
}

@Composable
fun Home(vm: MainViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("YESMIN AI", color = Cyan, fontSize = 26.sp, letterSpacing = 6.sp)
        if (YesminAccessibilityService.instance != null) Text("🟢 Screen automation ON", color = Purple, fontSize = 12.sp)
        Core(vm.listening || vm.busy)
        Text(if (vm.listening) "Sun rahi hoon…" else if (vm.busy) "Soch rahi hoon…" else "Namaste! Main Yesmin hoon 💜", color = Color.White)
        Spacer(Modifier.height(8.dp))
        Glass(Modifier.fillMaxWidth().heightIn(min = 90.dp)) {
            Text(vm.messages.lastOrNull { it.role == "assistant" }?.text ?: "Mic dabao ya type karo.", color = Color.White)
            if (vm.status.isNotBlank()) Text(vm.status, color = Cyan, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MicButton(vm)
            OutlinedButton({ vm.interrupt() }) { Text("🔇 Chup") }
        }
        Spacer(Modifier.height(8.dp))
        InputRow(vm)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip({ vm.quick("open_youtube") }, { Text("▶ YouTube") })
            AssistChip({ vm.quick("camera") }, { Text("📷 Camera") })
            AssistChip({ vm.quick("flashlight") { put("on", true) } }, { Text("🔦 On") })
            AssistChip({ vm.quick("flashlight") { put("on", false) } }, { Text("🔦 Off") })
            AssistChip({ vm.quick("settings") }, { Text("⚙ Settings") })
        }
    }
}

@Composable
fun Bubble(text: String, mine: Boolean) {
    val clip = LocalClipboardManager.current
    val parts = text.split("```")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        parts.forEachIndexed { i, p ->
            if (i % 2 == 0) { if (p.isNotBlank()) Glass(Modifier.padding(vertical = 3.dp)) { Text(p.trim(), color = if (mine) Cyan else Color.White) } }
            else {
                val code = p.substringAfter("\n", p).trim()
                Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF10101C)).padding(10.dp)) {
                    Text(code, color = Color(0xFFB9F6CA), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
                    TextButton({ clip.setText(AnnotatedString(code)) }) { Text("📋 Copy") }
                }
            }
        }
    }
}

@Composable
fun Chat(vm: MainViewModel) {
    val st = rememberLazyListState()
    LaunchedEffect(vm.messages.size) { if (vm.messages.isNotEmpty()) st.animateScrollToItem(vm.messages.size - 1) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), state = st) { itemsIndexed(vm.messages) { _, m -> Bubble(m.text, m.role == "user") } }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.weight(1f)) { InputRow(vm) } ; Spacer(Modifier.width(6.dp)); MicButton(vm) }
    }
}

@Composable
fun Tools(vm: MainViewModel, goChat: () -> Unit) {
    val ctx = LocalContext.current
    val ideas = listOf("Kotlin mein ek Compose button example likho", "HTML+CSS+JS ka todo app banao", "Python mein CSV padhne ka code likho", "Mere Android error ko debug karne mein madad karo")
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Coding workspace", color = Cyan, fontSize = 18.sp)
        ideas.forEach { Glass(Modifier.fillMaxWidth().clickable { vm.send(it); goChat() }) { Text(it, color = Color.White) } }
        Text("Screen assistant (Accessibility)", color = Cyan, fontSize = 18.sp)
        Glass(Modifier.fillMaxWidth()) {
            Text(if (YesminAccessibilityService.instance != null) "🟢 ON — har screen action se pehle aapse confirm poochungi." else "🔴 OFF — optional. Aapko manually enable karna hoga.", color = Color.White)
            Button({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Accessibility Settings kholo") }
        }
        Text("Quick phone controls", color = Cyan, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ vm.quick("volume") { put("dir", "up") } }) { Text("🔊 +") }
            OutlinedButton({ vm.quick("volume") { put("dir", "down") } }) { Text("🔉 −") }
            OutlinedButton({ vm.quick("browser") }) { Text("🌐") }
        }
        if (vm.status.isNotBlank()) Text(vm.status, color = Purple)
    }
}

@Composable
fun MemoryScreen(vm: MainViewModel) {
    var n by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Memory (sirf aapki approval se)", color = Cyan, fontSize = 18.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(n, { n = it }, Modifier.weight(1f), placeholder = { Text("Jaise: mujhe Bengali pasand hai") }, singleLine = true)
            Button({ vm.addMemory(n); n = "" }, Modifier.padding(start = 8.dp)) { Text("+") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(vm.memory) { i, m ->
                Glass(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m, Modifier.weight(1f), color = Color.White); TextButton({ vm.removeMemory(i) }) { Text("🗑") } } }
            }
        }
        OutlinedButton({ vm.clearMemory() }, Modifier.fillMaxWidth()) { Text("Saari memory clear karo") }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Voice language", color = Cyan, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("hi-IN" to "हिन्दी", "bn-IN" to "বাংলা", "en-US" to "English").forEach { (c, l) ->
                FilterChip(vm.lang == c, { vm.setLang(c) }, { Text(l) })
            }
        }
        Text("AI Brain", color = Cyan, fontSize = 18.sp)
        Ai.providers.forEach { (id, title) -> ProviderCard(vm, id, title) }
        Text("Gemini key: aistudio.google.com • Claude key: console.anthropic.com. Keys phone par encrypted store hoti hain.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun ProviderCard(vm: MainViewModel, id: String, title: String) {
    var key by remember { mutableStateOf(vm.store.key(id)) }
    var model by remember { mutableStateOf(vm.store.model(id)) }
    var on by remember { mutableStateOf(vm.store.enabled(id)) }
    var res by remember { mutableStateOf("") }
    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = Cyan); Switch(on, { on = it }) }
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            Button({ vm.store.save(id, key, model, on); res = "Saved ✅" }) { Text("Save") }
            OutlinedButton({ res = "Testing…"; vm.test(id, key, model) { res = it } }) { Text("Test connection") }
        }
        if (res.isNotBlank()) Text(res, color = Color.White, fontSize = 12.sp)
    }
}
