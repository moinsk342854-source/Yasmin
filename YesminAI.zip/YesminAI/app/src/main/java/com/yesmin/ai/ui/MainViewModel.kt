package com.yesmin.ai.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.ai.ai.Ai
import com.yesmin.ai.ai.Msg
import com.yesmin.ai.data.Store
import com.yesmin.ai.phone.PhoneActions
import com.yesmin.ai.voice.VoiceManager
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val actions = PhoneActions(app)
    val messages = mutableStateListOf<Msg>()
    val memory = mutableStateListOf<String>().apply { addAll(store.memory) }
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var status by mutableStateOf("")
    var lang by mutableStateOf(store.lang)
    var pendingAction by mutableStateOf<JSONObject?>(null)   // needs user confirmation (screen automation)
    var pendingMemory by mutableStateOf<String?>(null)       // needs user approval

    private val voice = VoiceManager(app, { send(it, true) }, { listening = it }, { status = it })

    private fun system() = """
You are Yesmin, a cheerful, caring, witty and respectful female AI assistant on an Android phone.
Reply in the user's language (Hindi/Hinglish, Bengali or English). Keep replies short and natural, because they may be spoken aloud.
You can also help with coding: put code in fenced blocks and explain simply.
To control the phone, append exactly one line at the end: [[ACTION:{json}]]. Allowed json:
{"type":"open_app","name":"..."} {"type":"open_youtube"} {"type":"youtube_search","query":"..."} {"type":"settings"}
{"type":"camera"} {"type":"browser","url":"https://..."} {"type":"alarm","hour":7,"minute":30,"label":"..."}
{"type":"flashlight","on":true} {"type":"volume","dir":"up|down|mute"}
Screen control (user confirms each): {"type":"scroll","dir":"up|down"} {"type":"click_text","text":"..."} {"type":"back"} {"type":"home"}
Never request payments, sending messages, deleting or submitting forms. Never say an action is done unless you emitted it.
If the user shares a lasting preference, append [[REMEMBER:short fact]]; the user will approve it.
Known user memory: ${memory.joinToString("; ").ifBlank { "none" }}
""".trimIndent()

    fun send(text: String, speak: Boolean = false) {
        if (text.isBlank() || busy) return
        messages += Msg("user", text); busy = true; status = ""
        viewModelScope.launch {
            try {
                val id = Ai.providers.map { it.first }.firstOrNull { store.enabled(it) && store.key(it).isNotBlank() }
                    ?: throw Exception("Settings mein provider enable karke API key daalo.")
                val reply = Ai.chat(id, store.key(id), store.model(id), system(), messages.takeLast(20).toList())
                handle(reply, speak)
            } catch (e: Exception) {
                messages += Msg("assistant", "⚠️ ${e.message}")
            } finally { busy = false }
        }
    }

    private fun handle(reply: String, speak: Boolean) {
        val re = Regex("\\[\\[(ACTION|REMEMBER):(.*?)\\]\\]", RegexOption.DOT_MATCHES_ALL)
        val clean = reply.replace(re, "").trim()
        messages += Msg("assistant", clean)
        if (speak && clean.isNotBlank()) voice.speak(clean.replace(Regex("```.*?```", RegexOption.DOT_MATCHES_ALL), ""), lang)
        re.findAll(reply).forEach { m ->
            if (m.groupValues[1] == "REMEMBER") pendingMemory = m.groupValues[2].trim()
            else runCatching { JSONObject(m.groupValues[2].trim()) }.onSuccess { j ->
                if (j.optString("type") in PhoneActions.A11Y) pendingAction = j else runAction(j)
            }
        }
    }

    fun runAction(j: JSONObject) { status = actions.run(j) }
    fun confirmAction() { pendingAction?.let { runAction(it) }; pendingAction = null }
    fun quick(type: String, extra: JSONObject.() -> Unit = {}) = runAction(JSONObject().put("type", type).apply(extra))

    fun toggleMic() { if (listening) voice.stopListening() else voice.listen(lang) }
    fun interrupt() = voice.stopSpeaking()

    fun setLang(l: String) { lang = l; store.lang = l }
    fun addMemory(s: String) { if (s.isNotBlank()) { memory += s.trim(); store.memory = memory.toList() } }
    fun removeMemory(i: Int) { memory.removeAt(i); store.memory = memory.toList() }
    fun clearMemory() { memory.clear(); store.memory = emptyList() }
    fun approveMemory() { pendingMemory?.let { addMemory(it) }; pendingMemory = null }

    fun test(id: String, key: String, model: String, done: (String) -> Unit) = viewModelScope.launch {
        done(try { "✅ Connected: " + Ai.chat(id, key, model, "Reply in 3 words.", listOf(Msg("user", "Say hello"))).take(60) }
             catch (e: Exception) { "❌ ${e.message}" })
    }

    override fun onCleared() { voice.shutdown() }
}
