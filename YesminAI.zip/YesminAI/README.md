# Yesmin AI
Build (Android Studio): open folder -> Run. CLI: `gradle wrapper && ./gradlew assembleDebug`
APK: app/build/outputs/apk/debug/app-debug.apk
Termux (fragile, ARM aapt2 needed): pkg install openjdk-17 gradle; install Android SDK 34 + build-tools;
echo "sdk.dir=$HOME/android-sdk" > local.properties
echo "android.aapt2FromMavenOverride=$HOME/android-sdk/build-tools/34.0.0/aapt2" >> gradle.properties
gradle wrapper && ./gradlew assembleDebug
Permissions: Mic (runtime), Alarm (normal), Accessibility (manual, Tools tab). Add API key in Settings first.
